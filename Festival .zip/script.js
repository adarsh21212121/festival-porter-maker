document.addEventListener('DOMContentLoaded', () => {

    // --- ADSTERA 3-CLICK POPUNDER LOGIC ---
    let clickCount = 0;
    const popunderScriptSrc = '//pl27303284.profitableratecpm.com/c3/17/f3/c317f3dda745b95ebad73eaa651ad209.js';
    
    document.body.addEventListener('click', () => {
        clickCount++;
        if (clickCount === 3) {
            const adScript = document.createElement('script');
            adScript.type = 'text/javascript';
            adScript.src = popunderScriptSrc;
            document.head.appendChild(adScript);
        }
    });
    // --- END OF AD LOGIC ---

    const canvas = document.getElementById('poster-canvas');
    const ctx = canvas.getContext('2d');

    let layers = [];
    let baseTemplate = null;
    let activeLayer = null;
    let isDragging = false, dragStartX, dragStartY;

    const TEMPLATES = ['holi.jpg', 'holi2.jpg', 'rakhi.jpg', 'rakhi2.jpg', 'rakhi3.jpg'];
    const FONTS = { "Baloo 2": "'Baloo 2', cursive", "Mukta": "'Mukta', sans-serif", "Lobster": "'Lobster', cursive", "Teko": "'Teko', sans-serif", "Pacifico": "'Pacifico', cursive" };
    const SOLID_COLORS = ['#FFFFFF', '#000000', '#e74c3c', '#f1c40f', '#2ecc71', '#3498db', '#9b59b6'];
    const GRADIENTS = { "Sunset Glow": ["#ff7e5f", "#feb47b"], "Holi Splash": ["#f7971e", "#ffd200"], "Royal Gold": ["#f2c94c", "#f2994a"], "Ocean Blue": ["#2193b0", "#6dd5ed"], "Lush Green": ["#56ab2f", "#a8e063"] };

    const templatesGrid = document.querySelector('.templates-grid');
    const layerList = document.getElementById('layer-list');
    const editControlsContainer = document.getElementById('edit-controls');
    const noLayerSelectedMsg = document.getElementById('no-layer-selected');

    function init() {
        setupTabs();
        setupEventListeners();
        populateAssets();
        renderCanvas();
    }

    function setupTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn, .tab-content').forEach(el => el.classList.remove('active'));
                btn.classList.add('active');
                document.getElementById(btn.dataset.tab).classList.add('active');
            });
        });
        document.querySelectorAll('.color-tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                btn.parentElement.querySelectorAll('.color-tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                btn.parentElement.parentElement.querySelectorAll('.color-tab-content').forEach(c => c.classList.remove('active'));
                document.getElementById(btn.dataset.colorTab + '-color-content').classList.add('active');
            });
        });
    }

    function populateAssets() {
        TEMPLATES.forEach(file => {
            const card = document.createElement('div');
            card.className = 'template-card';
            card.innerHTML = `<img src="images/templates/${file}" alt="${file}">`;
            card.addEventListener('click', () => selectTemplate(card, `images/templates/${file}`));
            templatesGrid.appendChild(card);
        });
        const fontSelect = document.getElementById('font-select');
        Object.keys(FONTS).forEach(name => fontSelect.innerHTML += `<option value="${FONTS[name]}">${name}</option>`);
        const solidPalette = document.getElementById('solid-palette');
        SOLID_COLORS.forEach(color => {
            const swatch = document.createElement('div');
            swatch.className = 'swatch';
            swatch.style.background = color;
            swatch.addEventListener('click', () => { if(activeLayer) { document.getElementById('text-color').value = color; updateActiveLayer('color1', color); } });
            solidPalette.appendChild(swatch);
        });
        const gradientPalette = document.getElementById('gradient-palette');
        Object.keys(GRADIENTS).forEach(name => gradientPalette.innerHTML += `<option value="${name}">${name}</option>`);
        gradientPalette.addEventListener('change', (e) => {
            if(!activeLayer) return;
            const colors = GRADIENTS[e.target.value];
            document.getElementById('gradient-start').value = colors[0];
            document.getElementById('gradient-end').value = colors[1];
            updateActiveLayer('color1', colors[0]);
            updateActiveLayer('color2', colors[1]);
        });
    }

    function renderCanvas() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (baseTemplate) ctx.drawImage(baseTemplate, 0, 0, canvas.width, canvas.height);
        layers.forEach(layer => {
            if (!layer.visible) return;
            ctx.save();
            ctx.translate(layer.x, layer.y);
            ctx.rotate(layer.rotation * Math.PI / 180);
            ctx.globalAlpha = layer.opacity;
            if (layer.type === 'text') drawText(layer);
            else if (layer.type === 'image') drawImage(layer);
            ctx.restore();
        });
        if (activeLayer) {
            ctx.save();
            ctx.translate(activeLayer.x, activeLayer.y);
            ctx.rotate(activeLayer.rotation * Math.PI / 180);
            ctx.strokeStyle = '#00aeff';
            ctx.lineWidth = 4;
            ctx.strokeRect(-activeLayer.width/2, -activeLayer.height/2, activeLayer.width, activeLayer.height);
            ctx.restore();
        }
    }

    function drawText(layer) {
        ctx.font = `${layer.size}px ${layer.font}`;
        ctx.textBaseline = 'middle';
        ctx.textAlign = 'center';
        const metrics = ctx.measureText(layer.content);
        layer.width = metrics.width;
        layer.height = metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;
        if (layer.colorType === 'gradient') {
            const grad = ctx.createLinearGradient(-layer.width/2, 0, layer.width/2, 0);
            grad.addColorStop(0, layer.color1);
            grad.addColorStop(1, layer.color2);
            ctx.fillStyle = grad;
        } else {
            ctx.fillStyle = layer.color1;
        }
        if (layer.shadow) {
            ctx.shadowColor = layer.shadowColor;
            ctx.shadowBlur = layer.shadowBlur;
            ctx.shadowOffsetX = 5;
            ctx.shadowOffsetY = 5;
        }
        ctx.fillText(layer.content, 0, 0);
    }

    function drawImage(layer) {
        ctx.save();
        if (layer.shape === 'circle') {
            ctx.beginPath();
            ctx.arc(0, 0, layer.width / 2, 0, Math.PI * 2);
            ctx.clip();
        }
        ctx.drawImage(layer.element, -layer.width / 2, -layer.height / 2, layer.width, layer.height);
        if (layer.borderWidth > 0) {
            ctx.lineWidth = layer.borderWidth;
            ctx.strokeStyle = layer.borderColor;
            if(layer.shape === 'circle') {
                 ctx.beginPath();
                 ctx.arc(0, 0, layer.width/2, 0, Math.PI * 2);
                 ctx.stroke();
            } else {
                 ctx.strokeRect(-layer.width / 2, -layer.height / 2, layer.width, layer.height);
            }
        }
        ctx.restore();
    }
    
    function renderLayerList() {
        layerList.innerHTML = '';
        [...layers].reverse().forEach(layer => {
            const li = document.createElement('li');
            li.draggable = true;
            li.dataset.id = layer.id;
            li.className = activeLayer && activeLayer.id === layer.id ? 'active' : '';
            li.innerHTML = `<i class="fas fa-grip-vertical"></i><span class="layer-name">${layer.type === 'text' ? (layer.content.substring(0, 15) || 'Text') : 'Photo'}</span><button class="toggle-vis" data-id="${layer.id}"><i class="fas ${layer.visible ? 'fa-eye' : 'fa-eye-slash'}"></i></button>`;
            li.addEventListener('click', () => setActiveLayer(layer));
            li.addEventListener('dragstart', (e) => e.dataTransfer.setData('text/plain', layer.id));
            li.addEventListener('dragover', (e) => e.preventDefault());
            li.addEventListener('drop', (e) => {
                e.preventDefault();
                const droppedId = e.dataTransfer.getData('text/plain');
                const droppedIndex = layers.findIndex(l => l.id == droppedId);
                const targetIndex = layers.findIndex(l => l.id == layer.id);
                const [movedLayer] = layers.splice(droppedIndex, 1);
                layers.splice(targetIndex, 0, movedLayer);
                renderAll();
            });
            layerList.appendChild(li);
        });
        document.querySelectorAll('.toggle-vis').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const layer = layers.find(l => l.id == e.currentTarget.dataset.id);
                if(layer) { layer.visible = !layer.visible; renderAll(); }
            });
        });
    }

    function renderAll() { renderCanvas(); renderLayerList(); }
    
    function addTextLayer() {
        const newText = { id: Date.now(), type: 'text', visible: true, content: 'Your Name', x: canvas.width / 2, y: canvas.height / 2, size: 80, font: FONTS['Baloo 2'], colorType: 'solid', color1: '#FFFFFF', color2: '#000000', width: 0, height: 0, rotation: 0, opacity: 1, shadow: false, shadowColor: '#000000', shadowBlur: 5 };
        layers.push(newText);
        setActiveLayer(newText);
        // --- यहाँ बदलाव किया गया है ---
        document.querySelector('.tab-btn[data-tab="edit-tab"]').click();
    }

    function addImageLayer(e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            const img = new Image();
            img.crossOrigin = "Anonymous";
            img.onload = () => {
                const newImage = { id: Date.now(), type: 'image', visible: true, element: img, x: canvas.width / 2, y: canvas.height / 2, width: 300, height: 300, rotation: 0, opacity: 1, shape: 'circle', borderWidth: 5, borderColor: '#FFFFFF' };
                layers.push(newImage);
                setActiveLayer(newImage);
                // --- यहाँ बदलाव किया गया है ---
                document.querySelector('.tab-btn[data-tab="edit-tab"]').click();
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    }
    
    function removeActiveLayer() {
        if (!activeLayer) return;
        layers = layers.filter(l => l.id !== activeLayer.id);
        setActiveLayer(null);
    }
    
    function setActiveLayer(layer) {
        activeLayer = layer;
        updateEditPanel();
        renderAll();
    }
    
    function updateActiveLayer(prop, value) {
        if (!activeLayer) return;
        activeLayer[prop] = value;
        renderCanvas();
    }
    
    function updateEditPanel() {
        if (!activeLayer) {
            editControlsContainer.classList.add('hidden');
            noLayerSelectedMsg.classList.remove('hidden');
            return;
        }
        editControlsContainer.classList.remove('hidden');
        noLayerSelectedMsg.classList.add('hidden');
        const isText = activeLayer.type === 'text';
        document.getElementById('text-specific-controls').classList.toggle('hidden', !isText);
        document.getElementById('image-specific-controls').classList.toggle('hidden', isText);
        document.getElementById('size-h').classList.toggle('hidden', isText || activeLayer.shape === 'circle');
        document.getElementById('pos-x').value = Math.round(activeLayer.x);
        document.getElementById('pos-y').value = Math.round(activeLayer.y);
        document.getElementById('size-w').value = Math.round(activeLayer.width);
        document.getElementById('rotation').value = activeLayer.rotation;
        document.getElementById('rotation-value').textContent = activeLayer.rotation;
        document.getElementById('opacity').value = activeLayer.opacity;
        document.getElementById('opacity-value').textContent = Math.round(activeLayer.opacity * 100);
        if (isText) {
            document.getElementById('text-content').value = activeLayer.content;
            document.getElementById('font-select').value = activeLayer.font;
            document.getElementById('text-color').value = activeLayer.color1;
            document.getElementById('gradient-start').value = activeLayer.color1;
            document.getElementById('gradient-end').value = activeLayer.color2;
            document.getElementById('text-shadow-enable').checked = activeLayer.shadow;
            document.getElementById('text-shadow-options').classList.toggle('hidden', !activeLayer.shadow);
            document.getElementById('text-shadow-color').value = activeLayer.shadowColor;
            document.getElementById('text-shadow-blur').value = activeLayer.shadowBlur;
        } else {
            document.getElementById('size-h').value = Math.round(activeLayer.height);
            document.getElementById('image-shape').value = activeLayer.shape;
            document.getElementById('image-border-width').value = activeLayer.borderWidth;
            document.getElementById('image-border-color').value = activeLayer.borderColor;
        }
    }
    
    function setupEventListeners() {
        document.getElementById('add-text-btn').addEventListener('click', addTextLayer);
        document.getElementById('add-photo-btn').addEventListener('click', () => document.getElementById('photo-input').click());
        document.getElementById('photo-input').addEventListener('change', addImageLayer);
        
        document.getElementById('pos-x').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('x', parseInt(e.target.value)); renderCanvas(); } });
        document.getElementById('pos-y').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('y', parseInt(e.target.value)); renderCanvas(); } });
        document.getElementById('size-w').addEventListener('input', e => {
            if(!activeLayer) return;
            const w = parseInt(e.target.value);
            if (activeLayer.type === 'image' && activeLayer.shape === 'circle') { updateActiveLayer('width', w); updateActiveLayer('height', w); document.getElementById('size-h').value = w; }
            else { updateActiveLayer('width', w); }
            renderCanvas();
        });
        document.getElementById('size-h').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('height', parseInt(e.target.value)); renderCanvas(); } });
        document.getElementById('rotation').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('rotation', parseInt(e.target.value)); document.getElementById('rotation-value').textContent = e.target.value; renderCanvas(); } });
        document.getElementById('opacity').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('opacity', parseFloat(e.target.value)); document.getElementById('opacity-value').textContent = Math.round(e.target.value * 100); renderCanvas(); } });
        
        document.getElementById('align-h-center').addEventListener('click', () => { if(activeLayer) { updateActiveLayer('x', canvas.width / 2); updateEditPanel(); renderCanvas(); }});
        document.getElementById('align-v-center').addEventListener('click', () => { if(activeLayer) { updateActiveLayer('y', canvas.height / 2); updateEditPanel(); renderCanvas(); }});

        document.getElementById('text-content').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('content', e.target.value); renderAll(); } });
        document.getElementById('font-select').addEventListener('change', e => { if(activeLayer) { updateActiveLayer('font', e.target.value); renderCanvas(); } });
        document.getElementById('text-color').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('color1', e.target.value); renderCanvas(); } });
        document.getElementById('gradient-start').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('color1', e.target.value); renderCanvas(); } });
        document.getElementById('gradient-end').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('color2', e.target.value); renderCanvas(); } });
        document.getElementById('text-shadow-enable').addEventListener('change', e => { if(activeLayer) { updateActiveLayer('shadow', e.target.checked); document.getElementById('text-shadow-options').classList.toggle('hidden', !e.target.checked); renderCanvas(); } });
        document.getElementById('text-shadow-color').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('shadowColor', e.target.value); renderCanvas(); } });
        document.getElementById('text-shadow-blur').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('shadowBlur', parseInt(e.target.value)); renderCanvas(); } });
        document.querySelector('.color-tab-btn[data-color-tab="solid"]').addEventListener('click', () => { if(activeLayer) updateActiveLayer('colorType', 'solid'); });
        document.querySelector('.color-tab-btn[data-color-tab="gradient"]').addEventListener('click', () => { if(activeLayer) updateActiveLayer('colorType', 'gradient'); });

        document.getElementById('image-shape').addEventListener('change', e => { if(activeLayer) { updateActiveLayer('shape', e.target.value); updateEditPanel(); renderCanvas(); } });
        document.getElementById('image-border-width').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('borderWidth', parseInt(e.target.value)); renderCanvas(); } });
        document.getElementById('image-border-color').addEventListener('input', e => { if(activeLayer) { updateActiveLayer('borderColor', e.target.value); renderCanvas(); } });

        document.getElementById('remove-layer-btn').addEventListener('click', removeActiveLayer);
        document.getElementById('download-btn').addEventListener('click', downloadPoster);
        document.getElementById('share-btn').addEventListener('click', generateShareLink);

        canvas.addEventListener('mousedown', onMouseDown);
        canvas.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);
        canvas.addEventListener('touchstart', onMouseDown, { passive: false });
        canvas.addEventListener('touchmove', onMouseMove, { passive: false });
        window.addEventListener('touchend', onMouseUp);
    }
    
    function onMouseDown(e) {
        e.preventDefault();
        const {mouseX, mouseY} = getMousePos(e);
        const clickedLayer = [...layers].reverse().find(l => {
            if(!l.visible) return false;
            const dx = mouseX - l.x, dy = mouseY - l.y;
            const angle = -l.rotation * Math.PI / 180;
            const rotatedX = dx * Math.cos(angle) - dy * Math.sin(angle);
            const rotatedY = dx * Math.sin(angle) + dy * Math.cos(angle);
            return Math.abs(rotatedX) < l.width/2 && Math.abs(rotatedY) < l.height/2;
        });
        
        if (clickedLayer) {
            setActiveLayer(clickedLayer);
            isDragging = true;
            canvas.classList.add('grabbing');
            dragStartX = mouseX - clickedLayer.x;
            dragStartY = mouseY - clickedLayer.y;
        } else {
            setActiveLayer(null);
        }
    }
    function onMouseMove(e) {
        if (!isDragging || !activeLayer) return;
        e.preventDefault();
        const {mouseX, mouseY} = getMousePos(e);
        activeLayer.x = mouseX - dragStartX;
        activeLayer.y = mouseY - dragStartY;
        updateEditPanel();
        renderCanvas();
    }
    function onMouseUp() { isDragging = false; canvas.classList.remove('grabbing'); }
    function getMousePos(e) {
        const rect = canvas.getBoundingClientRect();
        const event = e.touches ? e.touches[0] : e;
        return {
            mouseX: (event.clientX - rect.left) * (canvas.width / rect.width),
            mouseY: (event.clientY - rect.top) * (canvas.height / rect.height)
        };
    }
    
    function selectTemplate(card, src) {
        document.querySelectorAll('.template-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        baseTemplate = new Image();
        baseTemplate.crossOrigin = "Anonymous";
        baseTemplate.src = src;
        baseTemplate.onload = () => renderCanvas();
    }
    
    function downloadPoster() {
        setActiveLayer(null);
        setTimeout(() => {
            const link = document.createElement('a');
            link.download = 'my-festival-poster.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
            confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });
        }, 100);
    }

    function generateShareLink() {
        setActiveLayer(null);
        setTimeout(() => {
            const url = `${window.location.origin}${window.location.pathname.replace('index.html', '')}view.html?poster=${encodeURIComponent(canvas.toDataURL('image/png'))}`;
            navigator.clipboard.writeText(url).then(() => alert('Share link copied!'), () => alert('Could not copy link.'));
        }, 100);
    }

    init();
});